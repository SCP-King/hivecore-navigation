"""move_group：必须使用本包配置（含 joint_limits 仅含腿+轮）。

若日志出现 Joint 'left_arm_joint_*' not found in model 'hive2'，说明启动了
dual_arm_moveit_6dof 的 move_group，却把 robot_description 换成了 quad_leg。
请统一使用：ros2 launch hive2_moveit move_group.launch.py。
腿控节点（无 MoveIt）单独启动：ros2 launch leg_controller real_leg_3dof.launch.py。
勿与双臂 demo 混用。
"""
from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_move_group_launch


def generate_launch_description():
    moveit_config = (
        MoveItConfigsBuilder("hive2", package_name="hive2_moveit")
        .robot_description_kinematics(file_path="config/kinematics.yaml")
        .to_moveit_configs()
    )
    return generate_move_group_launch(moveit_config)
