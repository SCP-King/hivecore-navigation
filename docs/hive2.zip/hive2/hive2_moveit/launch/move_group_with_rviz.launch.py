from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_move_group_launch, generate_moveit_rviz_launch
from launch import LaunchDescription


def generate_launch_description():
    moveit_config = (
        MoveItConfigsBuilder("hive2", package_name="hive2_moveit")
        .robot_description_kinematics(file_path="config/kinematics.yaml")
        .to_moveit_configs()
    )
    return LaunchDescription([
        generate_move_group_launch(moveit_config),
        generate_moveit_rviz_launch(moveit_config),
    ])
